#include <iostream>
#include <string>
#include "Employee.h"

using namespace std;

int main()
{
	Employee yourDetails;

	yourDetails.SetEmpNo();
	yourDetails.SetEmpSalary();

	return 0;
}