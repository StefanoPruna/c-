// 9465_Stefano_tut5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <time.h>
#include "Date.h"

using namespace std;

int mainOne()
{
	Date theDate;

	theDate.SetDate(01, 01, 2021);

	return 0;
}

